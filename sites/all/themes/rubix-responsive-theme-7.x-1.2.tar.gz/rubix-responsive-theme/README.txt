About Rubix Responsive Theme
====================
Rubix theme is a drupal responsive skelton theme. The theme is not dependent on
any core theme. Its very light weight for fast loading with modern look.

Browser compatibility:
=====================
The theme has been tested on following browsers. IE8+, Firefox, Google Chrome,
Opera, Android Phone and Tablet, iPhone, iPad Browsers

Drupal compatibility:
=====================
This theme is compatible with Drupal 7.x.x

Developed by
===================
www.zymphonies.com